<?php
require "../db.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user["password"])) {

        $_SESSION["user_id"] = $user["id"];
        $_SESSION["role"] = $user["role"];
        $_SESSION["name"] = $user["name"];

        if ($user["role"] === "admin") {
            header("Location: ../admin/dashboard.php");
        } else {
            header("Location: ../customer/dashboard.php");
        }
        exit;
    } else {
        $error = "Invalid email or password";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Login - The Gardens</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

    <div class="auth-page">
        <div class="auth-card">
            <h2>Login</h2>
            <p class="muted">Welcome back to <b>The Gardens</b> 🌿</p>

            <?php if ($error): ?>
                <div class="alert"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="post">
                <label>Email</label>
                <input type="email" name="email" required>

                <label>Password</label>
                <input type="password" name="password" required>

                <button type="submit">Login</button>

                <p class="small-text">
                    Don’t have an account?
                    <a href="register.php">Register here</a>
                </p>
            </form>

            <a class="back-link" href="../index.php">← Back to Landing</a>
        </div>
    </div>

</body>

</html>