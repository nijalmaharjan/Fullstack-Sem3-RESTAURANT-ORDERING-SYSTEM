<?php
// auth/register.php
require "../db.php";

$message = "";
$message_color = "red";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $phone = trim($_POST["phone"] ?? "");
    $location = trim($_POST["location"] ?? "");

    if ($name === "" || $email === "" || $password === "" || $phone === "" || $location === "") {
        $message = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Invalid email format.";
    } elseif (!preg_match('/^\d{10}$/', $phone)) {
        $message = "Phone number must be exactly 10 digits.";
    }
    // 🔐 PASSWORD RULES START HERE
    elseif (strlen($password) < 7) {
        $message = "Password must be at least 7 characters long.";
    } elseif (!preg_match('/[A-Z]/', $password)) {
        $message = "Password must contain at least one capital letter.";
    } elseif (!preg_match('/[0-9]/', $password)) {
        $message = "Password must contain at least one number.";
    } elseif (!preg_match('/[^a-zA-Z0-9]/', $password)) {
        $message = "Password must contain at least one special character.";
    }
    // 🔐 PASSWORD RULES END HERE
    else {

        $check = $pdo->prepare("SELECT 1 FROM users WHERE email = ? LIMIT 1");
        $check->execute([$email]);

        if ($check->fetchColumn()) {
            $message = "Email already exists. Please use another email.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $role = "customer";

            $sql = "INSERT INTO users (name, email, password, role, phone, location)
                    VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$name, $email, $hashed_password, $role, $phone, $location]);

            $message = "Registration successful. You can now login.";
            $message_color = "green";
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Register - The Gardens</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

    <div class="auth-page">
        <div class="auth-card">
            <h2>Register</h2>
            <p class="muted">Create your account for <b>The Gardens</b> 🌿</p>

            <?php if ($message !== ""): ?>
                <div class="alert" style="border-left: 6px solid <?= $message_color === "green" ? "#1b7f4b" : "#d93025" ?>;">
                    <?= htmlspecialchars($message) ?>
                    <?php if ($message_color === "green"): ?>
                        <div style="margin-top:8px;">
                            <a href="login.php">Go to Login</a>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <form method="post" autocomplete="off">
                <label>Name</label>
                <input type="text" name="name" required>

                <label>Email</label>
                <input type="email" name="email" id="email" required>
                <small id="emailFeedback" style="display:block; margin-top:-6px; margin-bottom:12px;"></small>

                <label>Password</label>
                <input type="password" name="password" required>

                <label>Phone Number (10 digits)</label>
                <input type="text" name="phone" pattern="[0-9]{10}" required>

                <label>Location</label>
                <input type="text" name="location" required>

                <button type="submit">Register</button>

                <p class="small-text">
                    Already have an account?
                    <a href="login.php">Login here</a>
                </p>
            </form>

            <a class="back-link" href="../index.php">← Back to Landing</a>
        </div>
    </div>

    <!-- keep your existing email check -->
    <script>
        var emailInput = document.getElementById('email');
        var feedback = document.getElementById('emailFeedback');
        var timer = null;

        function setFeedback(text, ok) {
            feedback.textContent = text;
            feedback.style.color = ok ? 'green' : 'red';
        }

        emailInput.addEventListener('input', function() {
            var email = emailInput.value.trim();
            if (!email) {
                feedback.textContent = '';
                return;
            }

            clearTimeout(timer);
            timer = setTimeout(function() {
                var formData = new FormData();
                formData.append('email', email);

                fetch('check_email.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.error) {
                            setFeedback('Could not check email right now', false);
                            return;
                        }
                        if (data.message) {
                            setFeedback(data.message, !data.exists);
                        }
                    })
                    .catch(() => {
                        setFeedback('Network/server error while checking email', false);
                    });
            }, 350);
        });
    </script>

</body>

</html>