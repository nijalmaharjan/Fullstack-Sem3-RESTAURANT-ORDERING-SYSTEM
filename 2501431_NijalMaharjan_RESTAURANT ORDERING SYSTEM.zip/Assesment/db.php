<?php
// Start session for login system
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Database credentials
$host = "localhost";
$dbname = "NP03CS4A240039";
$username = "NP03CS4A240039";
$password = "khlSoj69Tk";

try {
    // Create PDO connection
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname",
        $username,
        $password
    );

    // Enable error mode for debugging
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Stop script if DB connection fails
    die("Database connection failed: " . $e->getMessage());
}
