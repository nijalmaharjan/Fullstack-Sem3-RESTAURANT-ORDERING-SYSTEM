<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>The Gardens</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body class="landing">

    <div class="landing-bg"></div>

    <div class="landing-wrap">
        <div class="landing-card">
            <h1>The Gardens 🌿</h1>
            <p class="muted">Fresh food • calm space • simple ordering

            </p>

            <div class="landing-actions">
                <a class="btn" href="auth/login.php">Login</a>
                <a class="btn btn-outline" href="auth/register.php">Register</a>
            </div>
        </div>
    </div>

</body>

</html>