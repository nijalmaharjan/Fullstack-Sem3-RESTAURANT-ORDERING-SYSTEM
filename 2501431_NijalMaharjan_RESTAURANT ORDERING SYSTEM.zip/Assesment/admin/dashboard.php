<?php
require "../db.php";

if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    die("Access denied");
}

$foods = $pdo->query("SELECT id, food_name, price, image FROM menu")->fetchAll();
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="/ASSESMENT/assets/css/style.css">
</head>

<body>
    <div class="admin-page">

        <div class="navbar">
            <strong>The Gardens (Admin)</strong>

            <div>
                <a href="add_food.php">Add Food</a>
                <a href="view_orders.php">View Orders</a>
                <a href="completed_orders.php">Completed Orders</a>
                <a href="../logout.php" class="logout-btn">Logout</a>
            </div>
        </div>

        <div class="page">
            <h2>Food Menu</h2>

            <div class="card-grid">
                <?php foreach ($foods as $food): ?>
                    <div class="food-card">

                        <div class="food-image">
                            <?php if ($food["image"]): ?>
                                <img src="../uploads/foods/<?= htmlspecialchars($food["image"]) ?>">
                            <?php else: ?>
                                No Image
                            <?php endif; ?>
                        </div>

                        <div class="food-body">
                            <h3><?= htmlspecialchars($food["food_name"]) ?></h3>
                            <p class="price">₹<?= $food["price"] ?></p>
                        </div>

                        <div class="food-actions">
                            <a href="edit_food.php?id=<?= $food["id"] ?>">Edit</a>
                            <a href="delete_food.php?id=<?= $food["id"] ?>" class="danger">Delete</a>
                        </div>

                    </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>
</body>

</html>

<style>
    /* ===== ADMIN DASHBOARD (internal css) ===== */
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    body {
        font-family: system-ui, Arial, sans-serif;
        background: #f4fbf7;
        color: #1f2d25;
    }

    /* a { */
    /* text-decoration: none; */
    /* } */

    .admin-page {
        min-height: 100vh;
        padding-bottom: 40px;
    }

    .page {
        max-width: 1100px;
        margin: 20px auto;
        padding: 0 16px;
    }

    .navbar {
        max-width: 1100px;
        margin: 20px auto;
        background: #fff;
        border: 1px solid #e6eee8;
        border-radius: 14px;
        padding: 14px 18px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .nav-links a {
        text-decoration: none;
        color: #1b7f4b;
        font-weight: 700;
        margin-right: 14px;
    }

    .nav-links a:hover {
        text-decoration: underline;
    }

    .logout-btn {
        background: #d93025;
        color: #fff;
        text-decoration: none;
        padding: 8px 14px;
        border-radius: 8px;
        font-weight: 700;
    }

    /* cards */
    .card-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        margin-top: 10px;
    }

    .food-card {
        width: 23%;
        background: #fff;
        border: 1px solid #e6eee8;
        border-radius: 14px;
        overflow: hidden;
    }

    .food-image {
        height: 160px;
        background: #e7f6ee;
        overflow: hidden;
    }

    .food-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
    }

    .food-body {
        padding: 14px;
        text-align: center;
    }

    .food-body h3 {
        margin-bottom: 6px;
        font-size: 18px;
    }

    .price {
        color: #13623a;
        font-weight: 800;
    }

    .food-actions {
        border-top: 1px solid #e6eee8;
        padding: 12px;
        display: flex;
        justify-content: space-between;
    }

    .food-actions a {
        text-decoration: none;
        font-weight: 700;
        color: #1b7f4b;
        font-size: 14px;
    }

    .food-actions a:hover {
        text-decoration: underline;
    }

    .food-actions a.danger {
        color: #d93025;
    }
</style>