<?php
require "../db.php";

if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    die("Access denied");
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name  = $_POST["food_name"];
    $price = $_POST["price"];

    $imageName = null;

    if (!empty($_FILES["image"]["name"])) {
        $ext = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);
        $imageName = uniqid() . "." . $ext;

        $uploadPath = "../uploads/foods/" . $imageName;
        move_uploaded_file($_FILES["image"]["tmp_name"], $uploadPath);
    }

    $stmt = $pdo->prepare(
        "INSERT INTO menu (food_name, price, image) VALUES (?, ?, ?)"
    );
    $stmt->execute([$name, $price, $imageName]);

    $message = "Food added successfully";
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Add Food</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <div class="admin-page">

        <div class="navbar">
            <a href="dashboard.php">Back</a>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>

        <div class="page">
            <div class="form-box">
                <h2>Add Food</h2>

                <?php if ($message): ?>
                    <p><?= $message ?></p>
                <?php endif; ?>

                <form method="post" enctype="multipart/form-data">
                    <label>Food Name</label>
                    <input type="text" name="food_name" required>

                    <label>Price</label>
                    <input type="number" name="price" required>

                    <label>Food Image</label>
                    <input type="file" name="image">

                    <button type="submit">Add Food</button>
                </form>

                <a class="back-link" href="dashboard.php">← Back to Dashboard</a>
            </div>
        </div>

    </div>
</body>

</html>