<?php
require "../db.php";

if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    die("Access denied");
}

if (!isset($_GET["id"])) {
    die("Invalid request");
}

$order_id = (int)$_GET["id"];

// Update order status
$stmt = $pdo->prepare(
    "UPDATE orders 
     SET status = 'completed', completed_at = NOW()
     WHERE id = ?"
);
$stmt->execute([$order_id]);

header("Location: view_orders.php");
exit;
