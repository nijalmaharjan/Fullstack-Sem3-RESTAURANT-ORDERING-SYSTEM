<?php
require "../db.php";

if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    die("Access denied");
}

// Fetch ONLY completed orders + phone + location
$sql = "
SELECT 
    orders.*,
    users.name AS customer_name,
    users.phone AS customer_phone,
    users.location AS customer_location,
    menu.food_name
FROM orders
JOIN users ON orders.user_id = users.id
JOIN menu ON orders.food_id = menu.id
WHERE orders.status = 'completed'
ORDER BY orders.completed_at DESC
";

$orders = $pdo->query($sql)->fetchAll();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Completed Orders</title>
    <link rel="stylesheet" href="/ASSESMENT/assets/css/style.css">
</head>

<body>

    <div class="admin-page">

        <div class="navbar">
            <a href="dashboard.php">Dashboard</a>
            <a href="view_orders.php">Pending Orders</a>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>

        <div class="page">
            <h2>Completed Orders</h2>

            <table class="orders-table">
                <tr>
                    <th>Customer</th>
                    <th>Phone</th>
                    <th>Location</th>
                    <th>Food</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Ordered At</th>
                    <th>Completed At</th>
                </tr>

                <?php if (count($orders) === 0): ?>
                    <tr>
                        <td colspan="8">No completed orders.</td>
                    </tr>
                <?php endif; ?>

                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?= htmlspecialchars($order["customer_name"]) ?></td>
                        <td><?= htmlspecialchars($order["customer_phone"] ?? "—") ?></td>
                        <td><?= htmlspecialchars($order["customer_location"] ?? "—") ?></td>
                        <td><?= htmlspecialchars($order["food_name"]) ?></td>
                        <td><?= (int)$order["quantity"] ?></td>
                        <td><?= htmlspecialchars($order["total_price"]) ?></td>
                        <td><?= htmlspecialchars($order["order_date"]) ?></td>
                        <td><?= htmlspecialchars($order["completed_at"] ?? "—") ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>

            <a class="back-link" href="dashboard.php">← Back to Dashboard</a>
        </div>

    </div>

</body>

</html>

<style>
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0
    }

    body {
        font-family: system-ui, Arial, sans-serif;
        background: #f4fbf7;
        color: #1f2d25
    }

    .admin-page {
        min-height: 100vh;
        padding-bottom: 40px
    }

    .page {
        max-width: 1100px;
        margin: 20px auto;
        padding: 0 16px
    }

    .navbar {
        max-width: 1100px;
        margin: 20px auto;
        background: #fff;
        border: 1px solid #e6eee8;
        border-radius: 14px;
        padding: 14px 18px;
        display: flex;
        align-items: center;
        justify-content: space-between
    }

    .navbar a {
        text-decoration: none;
        color: #1b7f4b;
        font-weight: 700;
        margin-right: 14px
    }

    .logout-btn {
        background: #d93025;
        color: #fff !important;
        text-decoration: none;
        padding: 8px 14px;
        border-radius: 8px;
        font-weight: 700
    }

    h2 {
        margin: 10px 0 16px
    }

    .orders-table {
        width: 100%;
        background: #fff;
        border: 1px solid #e6eee8;
        border-radius: 12px;
        overflow: hidden;
        border-collapse: collapse
    }

    .orders-table th {
        background: #e7f6ee;
        padding: 14px;
        text-align: left;
        font-size: 14px
    }

    .orders-table td {
        padding: 14px;
        border-bottom: 1px solid #e6eee8;
        font-size: 14px
    }

    .orders-table tr:last-child td {
        border-bottom: none
    }

    .back-link {
        display: inline-block;
        margin-top: 16px;
        text-decoration: none;
        color: #1b7f4b;
        font-weight: 700
    }

    .back-link:hover {
        text-decoration: underline
    }
</style>