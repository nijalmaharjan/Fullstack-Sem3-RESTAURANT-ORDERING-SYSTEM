<?php
require "../db.php";

if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    die("Access denied");
}

if (!isset($_GET["id"])) {
    die("Invalid request");
}

$id = (int)$_GET["id"];
$message = "";

/* Fetch existing food */
$stmt = $pdo->prepare("SELECT * FROM menu WHERE id = ?");
$stmt->execute([$id]);
$food = $stmt->fetch();

if (!$food) {
    die("Food not found");
}

/* Update food */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name  = $_POST["food_name"];
    $price = $_POST["price"];

    $imageName = $food["image"]; // keep old image by default

    if (!empty($_FILES["image"]["name"])) {
        $ext = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);
        $imageName = uniqid() . "." . $ext;

        $uploadPath = "../uploads/foods/" . $imageName;
        move_uploaded_file($_FILES["image"]["tmp_name"], $uploadPath);
    }

    $update = $pdo->prepare(
        "UPDATE menu SET food_name = ?, price = ?, image = ? WHERE id = ?"
    );
    $update->execute([$name, $price, $imageName, $id]);

    $message = "Food updated successfully";
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Food</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

    <div class="admin-page">

        <div class="navbar">
            <a href="dashboard.php">Dashboard</a>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>

        <div class="page">
            <div class="form-box">

                <h2>Edit Food</h2>

                <?php if ($message): ?>
                    <p><?= htmlspecialchars($message) ?></p>
                <?php endif; ?>

                <?php if (!empty($food["image"])): ?>
                    <img src="../uploads/foods/<?= htmlspecialchars($food["image"]) ?>"
                        class="preview-img"
                        alt="Current food image">
                <?php endif; ?>

                <form method="post" enctype="multipart/form-data">
                    <label>Food Name</label>
                    <input type="text" name="food_name"
                        value="<?= htmlspecialchars($food["food_name"]) ?>" required>

                    <label>Price</label>
                    <input type="number" name="price"
                        value="<?= htmlspecialchars($food["price"]) ?>" required>

                    <label>Change Image (optional)</label>
                    <input type="file" name="image">

                    <button type="submit">Update Food</button>
                </form>

                <a class="back-link" href="dashboard.php">← Back to Dashboard</a>
            </div>
        </div>

    </div>

</body>

</html>