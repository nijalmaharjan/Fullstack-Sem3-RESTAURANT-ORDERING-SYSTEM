<link rel="stylesheet" href="/Assesment/assets/css/style.css">
<?php
require_once "../db.php";

if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    exit("Access denied");
}

$id = (int)($_GET["id"] ?? 0);
if ($id <= 0) {
    exit("Invalid food ID.");
}

// get image first
$stmt = $pdo->prepare("SELECT image FROM menu WHERE id = ?");
$stmt->execute([$id]);
$image = $stmt->fetchColumn();

if ($image) {
    $path = __DIR__ . "/../uploads/foods/" . $image;
    if (is_file($path)) {
        unlink($path);
    }
}

// delete row
$del = $pdo->prepare("DELETE FROM menu WHERE id = ?");
$del->execute([$id]);

header("Location: dashboard.php");
exit;
