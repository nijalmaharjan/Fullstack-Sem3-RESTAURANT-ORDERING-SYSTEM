const overlay = document.getElementById("overlay");

const loginModal = document.getElementById("loginModal");
const registerModal = document.getElementById("registerModal");

const openLoginButtons = [
  document.getElementById("openLogin"),
  document.getElementById("openLogin2"),
].filter(Boolean);

const openRegisterButtons = [
  document.getElementById("openRegister"),
  document.getElementById("openRegister2"),
].filter(Boolean);

const closeLogin = document.getElementById("closeLogin");
const closeRegister = document.getElementById("closeRegister");

const switchToRegister = document.getElementById("switchToRegister");
const switchToLogin = document.getElementById("switchToLogin");

function openModal(modal) {
  overlay.classList.add("show");
  modal.classList.add("show");
}

function closeAll() {
  overlay.classList.remove("show");
  loginModal.classList.remove("show");
  registerModal.classList.remove("show");
}

// Open login
openLoginButtons.forEach((btn) =>
  btn.addEventListener("click", () => {
    registerModal.classList.remove("show");
    openModal(loginModal);
  }),
);

// Open register
openRegisterButtons.forEach((btn) =>
  btn.addEventListener("click", () => {
    loginModal.classList.remove("show");
    openModal(registerModal);
  }),
);

// Close buttons
closeLogin.addEventListener("click", closeAll);
closeRegister.addEventListener("click", closeAll);

// Overlay click closes
overlay.addEventListener("click", closeAll);

// Switch links
switchToRegister.addEventListener("click", () => {
  loginModal.classList.remove("show");
  openModal(registerModal);
});
switchToLogin.addEventListener("click", () => {
  registerModal.classList.remove("show");
  openModal(loginModal);
});

// ESC closes
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeAll();
});
