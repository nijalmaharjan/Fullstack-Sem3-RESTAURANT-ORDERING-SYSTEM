<?php
session_start();
session_destroy();

// Redirect to landing page
header("Location: /ASSESMENT/index.php");
exit;
