<?php
session_start();
require "../db.php";

if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "customer") {
    die("Access denied");
}

$user_id = (int)($_SESSION["user_id"] ?? 0);
$quantities = $_POST["quantity"] ?? [];

if ($user_id <= 0) {
    die("User not found in session");
}

/* ===============================
   GET PHONE & LOCATION FROM USERS
================================ */
$userStmt = $pdo->prepare(
    "SELECT phone, location FROM users WHERE id = ? LIMIT 1"
);
$userStmt->execute([$user_id]);
$userRow = $userStmt->fetch(PDO::FETCH_ASSOC);

$phone    = $userRow["phone"] ?? null;
$location = $userRow["location"] ?? null;

/* ===============================
   CHECK AT LEAST ONE ITEM ORDERED
================================ */
$hasOrder = false;
foreach ($quantities as $qty) {
    if ((int)$qty > 0) {
        $hasOrder = true;
        break;
    }
}

if (!$hasOrder) {
    echo "<script>
        alert('Please select at least one item!');
        window.location.href = 'dashboard.php';
    </script>";
    exit;
}

/* ===============================
   INSERT ORDERS (FIXED)
================================ */
foreach ($quantities as $food_id => $qty) {

    $qty = (int)$qty;
    $food_id = (int)$food_id;

    if ($qty <= 0) continue;

    // get food price
    $stmt = $pdo->prepare(
        "SELECT price FROM menu WHERE id = ? LIMIT 1"
    );
    $stmt->execute([$food_id]);
    $food = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$food) continue;

    $total_price = $food["price"] * $qty;

    $insert = $pdo->prepare(
        "INSERT INTO orders
         (user_id, food_id, quantity, total_price, phone, location)
         VALUES (?, ?, ?, ?, ?, ?)"
    );

    $ok = $insert->execute([
        $user_id,
        $food_id,
        $qty,
        $total_price,
        $phone,
        $location
    ]);

    /* SHOW ERROR IF INSERT FAILS */
    if (!$ok) {
        echo "<pre>";
        print_r($insert->errorInfo());
        exit;
    }
}

/* ===============================
   SUCCESS
================================ */
echo "<script>
    alert('Order placed successfully!');
    window.location.href = 'dashboard.php';
</script>";
exit;
