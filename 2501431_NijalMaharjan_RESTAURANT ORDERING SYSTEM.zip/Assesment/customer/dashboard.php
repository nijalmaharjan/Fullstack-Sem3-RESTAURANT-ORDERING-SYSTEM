<?php
require "../db.php";

if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "customer") {
    die("Access denied");
}

$foods = $pdo->query("SELECT id, food_name, price, image FROM menu")->fetchAll();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Customer Dashboard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

    <div class="customer-page">

        <div class="navbar">
            <strong>The Gardens</strong>
            <a href="../logout.php" class="logout-btn">Logout</a>
        </div>

        <div class="page">
            <h2>Welcome, <?= htmlspecialchars($_SESSION["name"]) ?> 🌿</h2>
            <p class="sweet-msg">We’re happy to serve you today.</p>

            <form action="order.php" method="post">

                <div class="card-grid">
                    <?php foreach ($foods as $food): ?>
                        <div class="food-card">

                            <div class="food-image">
                                <?php if ($food["image"]): ?>
                                    <img src="../uploads/foods/<?= htmlspecialchars($food["image"]) ?>">
                                <?php endif; ?>
                            </div>

                            <div class="food-body">
                                <h3><?= htmlspecialchars($food["food_name"]) ?></h3>
                                <p class="price">₹ <?= $food["price"] ?></p>

                                <div class="qty-box">
                                    <button type="button" class="qty-btn"
                                        onclick="changeQty(<?= $food['id'] ?>, -1)">−</button>

                                    <input type="number"
                                        id="qty_<?= $food['id'] ?>"
                                        name="quantity[<?= $food['id'] ?>]"
                                        value="0" min="0"
                                        class="qty-input">

                                    <button type="button" class="qty-btn"
                                        onclick="changeQty(<?= $food['id'] ?>, 1)">+</button>
                                </div>
                            </div>

                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="order-bar">
                    <!-- <p>Ready to order?</p> -->
                    <button type="submit">Place Order</button>
                </div>

            </form>
        </div>
    </div>

    <script>
        function changeQty(id, change) {
            var input = document.getElementById("qty_" + id);
            var val = parseInt(input.value || 0) + change;
            if (val < 0) val = 0;
            input.value = val;
        }
    </script>

</body>

</html>